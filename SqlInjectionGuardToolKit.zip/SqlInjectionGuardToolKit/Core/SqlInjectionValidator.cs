﻿using SqlInjectionGuardToolKit.Attributes;
using SqlInjectionGuardToolKit.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace SqlInjectionGuardToolKit.Core
{
    public static class SqlInjectionValidator
    {
        /// <summary>
        /// All Sql Injection patterns to check against. This list can be expanded based on specific requirements and known attack vectors.
        /// </summary>
        private static readonly List<string> SqlInjectionPatterns = new()
        {
            //SQL Commands
            "SELECT", "INSERT", "UPDATE", "DELETE",
            "DROP", "TRUNCATE", "ALTER", "EXEC",
            "UNION", "MERGE", "CALL","Union","Union All",


            //Logical Operators and Common Injection Patterns
             " OR ", " AND ",
              "1=1", "1 = 1",
              "' OR '1'='1",
              "\" OR \"1\"=\"1",


              //System / Metadata Access
               "INFORMATION_SCHEMA",
                "SYSOBJECTS",
                "SYSCOLUMNS",
                "@@", "@@",

                // Dangerous Stored Procedures
             "XP_", "SP_",

              // Time-Based Injection
              "SLEEP(", "BENCHMARK(",
              "WAITFOR", "DELAY",

              // Encoding / Obfuscation Tricks
              "CHAR(", "NCHAR(",
              "VARCHAR(", "NVARCHAR(",

              // Data Manipulation Tricks
              "CAST(", "CONVERT(",

              // Execution / Dynamic SQL
              "DECLARE", "OPENROWSET",
              "OPENDATASOURCE"
        };

        /// <summary>
        /// String sanitization method to check for potential SQL injection patterns. 
        /// It returns a ValidationResult indicating whether the input is safe or not, 
        /// along with details about any detected patterns and the location of the input.
        /// </summary>
        /// <param name="input"></param>
        /// <param name="location"></param>
        /// <param name="options"></param>
        /// <returns></returns>
        public static ValidationResult SanitizeString(string? input, string? location = null, ValidatorOptions? options = null)
        {
            options ??= new ValidatorOptions();
            if (string.IsNullOrWhiteSpace(input))
                return safeResult(input, location);

            var KeywordsToCheck = SqlInjectionPatterns.Concat(options.CustomKeywords).Distinct().ToList();
            var upperInput = input.ToUpperInvariant();
            var detactedPattern = KeywordsToCheck.FirstOrDefault(keyword => upperInput.Contains(keyword.ToUpperInvariant()));
            if (detactedPattern != null)
            {
                return new ValidationResult
                {
                    IsValid = false,
                    OriginalVal = input,
                    SanitizedVal = options.ReplaceUnsafeWithBlank ? string.Empty : input,
                    DetectedPattern = detactedPattern,
                    Location = location ?? "Unknown"
                };
            }
            return safeResult(input, location);
        }

        public static List<ValidationResult> SanitizeSafeStrings(object obj, ValidatorOptions? options = null)
        {
            options ??= new ValidatorOptions();
            var results = new List<ValidationResult>(); 
            var type = obj.GetType();
            var validateAllString = type.GetCustomAttributes<SafeClassStringAttribute>() != null;
            var memebers = type.GetMembers(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
            foreach (var member in memebers)
            {
                if(member is PropertyInfo prop && prop.PropertyType == typeof(string))
                {
                    ProcessMember(prop, obj, validateAllString, options, results);
                }
                if (member is FieldInfo field && field.FieldType == typeof(string))
                {
                    ProcessMember(field, obj, validateAllString, options, results);
                }
            }
            return results;
        }

        private static void ProcessMember(MemberInfo member, object obj, bool validateAll, ValidatorOptions options, List<ValidationResult> results)
        {
            bool hasAttribute = member.GetCustomAttribute<SafeStringAttribute>() != null;

            if (!validateAll && !hasAttribute)
                return;

            string? value = member switch
            {
                PropertyInfo p => p.GetValue(obj) as string,
                FieldInfo f => f.GetValue(obj) as string,
                _ => null
            };

            var result = SanitizeString(value, member.Name, options);

            if (!result.IsValid && options.ReplaceUnsafeWithBlank)
            {
                if (member is PropertyInfo prop && prop.CanWrite)
                    prop.SetValue(obj, string.Empty);

                if (member is FieldInfo field)
                    field.SetValue(obj, string.Empty);
            }

            results.Add(result);
        }

        private static ValidationResult safeResult(string? input, string? location)
        {
            return new ValidationResult
            {
                IsValid = true,
                OriginalVal = input!,
                SanitizedVal = input!,
                DetectedPattern = null!,
                Location = location!
            };
        }
    }
}
