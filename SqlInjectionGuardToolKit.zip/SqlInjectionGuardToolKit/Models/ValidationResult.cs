﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlInjectionGuardToolKit.Models
{
    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public string OriginalVal { get; set; } = string.Empty;

        public string SanitizedVal { get; set; } = string.Empty;
        public string DetectedPattern { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;

    }
}
